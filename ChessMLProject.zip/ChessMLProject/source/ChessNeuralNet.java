import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ChessNeuralNet extends PApplet {

boardSpot[][] mainBoard;
ArrayList<Piece> blackPieces;
ArrayList<Piece> whitePieces;
ArrayList<boardSpot> whiteMoveList;
ArrayList<boardSpot> blackMoveList;
ArrayList<Piece> blackPawns;
ArrayList<Piece> whitePawns;
boolean mouseDelay;
Piece selectedPiece;
boolean pieceSelected;
boardSpot selectedSpot;
int turn; //-1=white, 1=black
int winningPlayer; //-1=white, 1=black
boolean gameOver;
int gameOverFrame;
boolean whiteChecked;
boolean blackChecked;
boolean turnChange;
boolean whiteCheckedTest;
boolean blackCheckedTest;
boolean tied;
int turnsSince;
int whiteRepeat;
int blackRepeat;
char[] boardPos={'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', };
PImage[] whitePieceImages;
PImage[] blackPieceImages;
int pawnChoice;
boolean pawnPromote;
ArrayList<Brain> blackBrains= new ArrayList<Brain>();
ArrayList<Brain> whiteBrains= new ArrayList<Brain>();
int currentBrain=0;
Brain blackBrain;
Brain whiteBrain;
int gameType=0;//0=player v player, 1=player v AI, 2= training: AI v AI
boolean gameStarted=false;
boolean turnHasHappened;
boolean addedBrain=false;
public void setup()
{
  
  mainBoard= new boardSpot[8][8];
  blackPieces= new ArrayList<Piece>();
  whitePieces= new ArrayList<Piece>();
  blackMoveList= new ArrayList<boardSpot>();
  whiteMoveList= new ArrayList<boardSpot>();
  blackPawns= new ArrayList<Piece>();
  whitePawns= new ArrayList<Piece>();
  boardSetup();
  selectedSpot=null;
  pieceSelected=false;
  selectedPiece=null;
  turn=-1;
  winningPlayer=0;
  gameOver=false;
  if (gameType!=2) {
    turnChange=false;
  }
  whiteCheckedTest=false;
  blackCheckedTest=false;
  turnsSince=0;
  tied=false;
  whiteRepeat=0;
  blackRepeat=0;
  whitePieceImages= new PImage[4];
  blackPieceImages= new PImage[4];
  whitePieceImages[0]=loadImage("white_rook.png");
  whitePieceImages[1]=loadImage("white_knight.png");
  whitePieceImages[2]=loadImage("white_bishop.png");
  whitePieceImages[3]=loadImage("white_queen.png");

  blackPieceImages[0]=loadImage("black_rook.png");
  blackPieceImages[1]=loadImage("black_knight.png");
  blackPieceImages[2]=loadImage("black_bishop.png");
  blackPieceImages[3]=loadImage("black_queen.png");

  pawnChoice=-1;
  pawnPromote=false;
  newBrains();
  blackBrain= blackBrains.get(currentBrain);
  whiteBrain= whiteBrains.get(currentBrain);
  updateNumbers();
  turnHasHappened=true;
  addedBrain=false;
}
public void draw() {
  background(0xffd6b333);
  if (gameStarted==false) {
    textSize(32);
    fill(0);
    textAlign(CENTER);
    text("Please Choose Your Game!", width/2, height/2-130);
    text("Press the Number corresponding to your chocie:", width/2, height/2-100);
    text("0: Player VS Player", width/2, height/2-50);
    text("1: Player VS AI", width/2, height/2-10);
    text("2: AI VS AI", width/2, height/2+30);
  }
  if (gameOver==false && gameStarted==true) {
    boardDisplay();
    GUI();
    if (turnChange==true) {
      checkBlackInCheck();
      checkWhiteInCheck();
      drawCheck();
      blackWin();
      whiteWin();
      updateNumbers();
      if (gameType==1) {
        if (turn==1) {
          blackBrain.think();
          delay(500);
        }
      }
      if (gameType==2) {
        if (turn==1) {
          blackBrain.think();
          delay(500);
        } else {
          whiteBrain.think();
          delay(500);
        }
        turn*=-1;
      }
      if (gameType!=2) {
        turnChange=false;
        turnHasHappened=true;
      }
    }
  } else if (gameStarted==true && gameOver==true) {
    if (tied==false) {
      String winner="";
      switch(winningPlayer) {
      case -1:
        winner="White";
        break;

      case 1:
        winner="Black";
        break;
      }
      int countDown= ((gameOverFrame+300)-frameCount)/60;
      textAlign(CENTER);
      fill(0);
      textSize(56);
      text(winner+" has won!", width/2, height/2);
      textSize(32);
      text(countDown+" till next round", width/2, height/2+25);
      if (countDown<=0) {
        setup();
      }
    } else {
      int countDown= ((gameOverFrame+300)-frameCount)/60;
      textAlign(CENTER);
      fill(0);
      textSize(56);
      text("There was a draw!", width/2, height/2);
      textSize(32);
      text(countDown+" till next round", width/2, height/2+25);
      if (countDown<=0) {
        setup();
      }
    }
    if (gameType==2 && addedBrain==false) {
      if (currentBrain==4) {
        train();
        currentBrain=0;
        addedBrain=true;
      } else {
        currentBrain++;
        addedBrain=true;
        println(currentBrain);
      }
    }
  }
}
public void keyPressed() {
  if (key=='0') {
    if (gameStarted==false) {
      gameType=0;
      gameStarted=true;
    }
  }
  if (key=='1') {
    if (gameStarted==false) {
      gameType=1;
      gameStarted=true;
      playerVAIsetup();
    }
  }
  if (key=='2') {
    if (gameStarted==false) {
      gameType=2;
      gameStarted=true;
      aiVaiSetup();
    }
  }
}
public void playerVAIsetup() {
  String[] bestSaved=loadStrings("weight_save.txt");
  float[] bestWeights= new float[4];
  for(int i=0; i<bestSaved.length;i++){
    bestWeights[i]= Float.parseFloat(bestSaved[i]);
  }
  blackBrain=new Brain(1,bestWeights);
}
public void aiVaiSetup() {
  String[] bestSaved=loadStrings("weight_save.txt");
  float[] bestWeights= new float[4];
  for(int i=0; i<bestSaved.length;i++){
    bestWeights[i]= Float.parseFloat(bestSaved[i]);
  }
  AISetup(bestWeights);
  turnChange=true;
}
public void updateNumbers() {
  for (int i=0; i<blackPieces.size(); i++) {
    blackPieces.get(i).setPieceNumber(i);
  }
  for (int i=0; i<whitePieces.size(); i++) {
    whitePieces.get(i).setPieceNumber(i);
  }
}
public void checkBlackInCheck() {
  allPossibleMovesWhite();
  for (int i=0; i<blackPieces.size(); i++) {
    if (blackPieces.get(i).name()=="king") {
      for (int j=0; j<whiteMoveList.size(); j++) {
        if (blackPieces.get(i).getArrayRow()==whiteMoveList.get(j).getArrayRow()&& blackPieces.get(i).getColumn()==whiteMoveList.get(j).getColumn()) {
          blackChecked=true;
        }
      }
    }
  }
}
public void checkBlackInCheckTest() {
  allPossibleMovesWhite();
  for (int i=0; i<blackPieces.size(); i++) {
    if (blackPieces.get(i).name()=="king") {
      for (int j=0; j<whiteMoveList.size(); j++) {
        if (blackPieces.get(i).getArrayRow()==whiteMoveList.get(j).getArrayRow()&& blackPieces.get(i).getColumn()==whiteMoveList.get(j).getColumn()) {
          blackCheckedTest=true;
        }
      }
    }
  }
}
public void checkWhiteInCheck() {
  allPossibleMovesBlack();
  whiteChecked=false;
  for (int i=0; i<whitePieces.size(); i++) {
    if (whitePieces.get(i).name()=="king") {
      for (int j=0; j<blackMoveList.size(); j++) {
        if (whitePieces.get(i).getArrayRow()==blackMoveList.get(j).getArrayRow()&& whitePieces.get(i).getColumn()==blackMoveList.get(j).getColumn()) {
          whiteChecked=true;
        }
      }
    }
  }
}
public void checkWhiteInCheckTest() {
  allPossibleMovesBlack();
  whiteCheckedTest=false;
  for (int i=0; i<whitePieces.size(); i++) {
    if (whitePieces.get(i).name()=="king") {
      for (int j=0; j<blackMoveList.size(); j++) {
        if (whitePieces.get(i).getArrayRow()==blackMoveList.get(j).getArrayRow()&& whitePieces.get(i).getColumn()==blackMoveList.get(j).getColumn()) {
          whiteCheckedTest=true;
        }
      }
    }
  }
}
public void GUI() {
  textAlign(CENTER);
  textSize(32);
  fill(0);
  String currentTurn="";
  switch(turn) {
  case -1:
    currentTurn="White's Turn";
    break;

  case 1:
    currentTurn="Black's Turn";
    break;
  }
  text(currentTurn, width/2+10, 45);
  int y=150;
  for (int i=8; i>0; i--) {
    text(i, 85, y);
    y+=100;
  }
  int x=150;
  for (int i=0; i<boardPos.length; i++) {
    text(boardPos[i], x, 85);
    x+=100;
  }
}
public void boardDisplay() {
  for (int i=0; i<mainBoard.length; i++) {
    for (int j=0; j<8; j++) {
      mainBoard[i][j].display();
    }
  }
  for (int i=0; i<blackPieces.size(); i++) {
    blackPieces.get(i).display();
    if (blackPieces.get(i).name()=="pawn" && blackPieces.get(i).getArrayRow()==7) {
      pawnPromote=true;
      pawnPromotion(false);
      if (pawnChoice!=-1) {
        switch(pawnChoice) {
        case 0:
          blackPieces.add(new Rook(blackPieces.get(i).getX(), blackPieces.get(i).getY(), 1, false));
          mainBoard[blackPieces.get(i).getArrayRow()][blackPieces.get(i).getColumn()].setCurrentPiece(1);
          blackPieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;

        case 1:
          blackPieces.add(new Knight(blackPieces.get(i).getX(), blackPieces.get(i).getY(), 1));
          mainBoard[blackPieces.get(i).getArrayRow()][blackPieces.get(i).getColumn()].setCurrentPiece(1);
          blackPieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;

        case 2:
          blackPieces.add(new Bishop(blackPieces.get(i).getX(), blackPieces.get(i).getY(), 1, false));
          mainBoard[blackPieces.get(i).getArrayRow()][blackPieces.get(i).getColumn()].setCurrentPiece(1);
          blackPieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;

        case 3:
          blackPieces.add(new Queen(blackPieces.get(i).getX(), blackPieces.get(i).getY(), 1));
          mainBoard[blackPieces.get(i).getArrayRow()][blackPieces.get(i).getColumn()].setCurrentPiece(1);
          blackPieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;
        }
      }
    }
  }
  for (int i=0; i<whitePieces.size(); i++) {
    whitePieces.get(i).display();
    if (whitePieces.get(i).name()=="pawn" && whitePieces.get(i).getArrayRow()==0) {
      pawnPromote=true;
      pawnPromotion(true);
      if (pawnChoice!=-1) {
        switch(pawnChoice) {
        case 0:
          whitePieces.add(new Rook(whitePieces.get(i).getX(), whitePieces.get(i).getY(), -1, false));
          mainBoard[whitePieces.get(i).getArrayRow()][whitePieces.get(i).getColumn()].setCurrentPiece(1);
          whitePieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;

        case 1:
          whitePieces.add(new Knight(whitePieces.get(i).getX(), whitePieces.get(i).getY(), -1));
          mainBoard[whitePieces.get(i).getArrayRow()][whitePieces.get(i).getColumn()].setCurrentPiece(1);
          whitePieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;

        case 2:
          whitePieces.add(new Bishop(whitePieces.get(i).getX(), whitePieces.get(i).getY(), -1, false));
          mainBoard[whitePieces.get(i).getArrayRow()][whitePieces.get(i).getColumn()].setCurrentPiece(1);
          whitePieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;

        case 3:
          whitePieces.add(new Queen(whitePieces.get(i).getX(), whitePieces.get(i).getY(), -1));
          mainBoard[whitePieces.get(i).getArrayRow()][whitePieces.get(i).getColumn()].setCurrentPiece(1);
          whitePieces.remove(i);
          pawnPromote=false;
          pawnChoice=-1;
          break;
        }
      }
    }
  }
}
public void allPossibleMovesWhite() {
  whiteMoveList.clear();
  for (int i=0; i<whitePieces.size(); i++) {
    whitePieces.get(i).caculateMoves(true);
    whiteMoveList.addAll(whitePieces.get(i).getAllMoves());
    whitePieces.get(i).clearMoves();
  }
}
public void allPossibleMovesBlack() {
  blackMoveList.clear();
  for (int i=0; i<blackPieces.size(); i++) {
    blackPieces.get(i).caculateMoves(true);
    blackMoveList.addAll(blackPieces.get(i).getAllMoves());
    blackPieces.get(i).clearMoves();
  }
}
public void mouseReleased()
{
  mouseDelay=false;
}
public void train() {
  //finding brain with largest points
  Brain bestBrain=whiteBrains.get(0);
  for (int i=0; i<whiteBrains.size(); i++) {
    if (whiteBrains.get(i).getPoints()>bestBrain.getPoints()) {
      bestBrain=whiteBrains.get(i);
    }
    if (blackBrains.get(i).getPoints()>bestBrain.getPoints()) {
      bestBrain=blackBrains.get(i);
    }
  }
  //getting weights off brain
  float[] bestWeights=bestBrain.getWeights();
  saveBestWeight(bestWeights);
  //clearing old brains
  whiteBrains.clear();
  blackBrains.clear();
  
  //creating new brains based off of old weights
  float[] newWeights=bestWeights;
  for (int i=0; i<4; i++) {
    newWeights=bestWeights;
    for (int j=0; j<newWeights.length; j++)
    {
      if (newWeights[j]-.01f<0) {
        newWeights[j] = newWeights[j] +random(-0.01f, 0.01f);
      }
      else{
        newWeights[j] = newWeights[j] +random(0, 0.01f);
      }
    }
    whiteBrains.add(new Brain(-1,newWeights));
    
    newWeights=bestWeights;
    for (int j=0; j<newWeights.length; j++)
    {
      if (newWeights[j]-.01f<0) {
        newWeights[j] = newWeights[j] +random(-0.01f, 0.01f);
      }
      else{
        newWeights[j] = newWeights[j] +random(0, 0.01f);
      }
    }
    blackBrains.add(new Brain(1,newWeights));
  }
  //adding completly new brains
  whiteBrains.add(new Brain(-1));
  blackBrains.add(new Brain(1));
  println("Succesful train");
}
public void saveBestWeight(float[] bestWeight){
  String[] save= new String[bestWeight.length];
  for(int i=0; i<bestWeight.length;i++){
    save[i]=bestWeight[i]+"";
  }
  saveStrings("weight_save.txt",save);
}
public void newBrains(){
  for(int i=0; i<5; i++){
    whiteBrains.add(new Brain(-1));
    blackBrains.add(new Brain(1));
  }
}
public void AISetup(float[] bestWeights) {
  //clearing old brains
  whiteBrains.clear();
  blackBrains.clear();
  //creating new brains based off of old weights
  float[] newWeights=bestWeights;
  for (int i=0; i<4; i++) {
    newWeights=bestWeights;
    for (int j=0; j<newWeights.length; j++)
    {
      if (newWeights[j]-.01f<0) {
        newWeights[j] = newWeights[j] +random(-0.01f, 0.01f);
      }
      else{
        newWeights[j] = newWeights[j] +random(0, 0.01f);
      }
    }
    whiteBrains.add(new Brain(-1,newWeights));
    
    newWeights=bestWeights;
    for (int j=0; j<newWeights.length; j++)
    {
      if (newWeights[j]-.01f<0) {
        newWeights[j] = newWeights[j] +random(-0.01f, 0.01f);
      }
      else{
        newWeights[j] = newWeights[j] +random(0, 0.01f);
      }
    }
    blackBrains.add(new Brain(1,newWeights));
  }
  //adding completly new brains
  whiteBrains.set(0, new Brain(-1,bestWeights));
  whiteBrains.add(new Brain(-1));
  blackBrains.add(new Brain(1));
  println("Succesful train");
}
public class Bishop extends Piece {
  boolean isWhite;
  public Bishop(float x, float y, int type, boolean isWhite) {
    super(x, y, type, "bishop",5);
    this.isWhite=isWhite;
  }
  @Override
    public void caculateMoves(boolean kingCalc) {
    //up-left
    for (int i=1; i<8; i++) {
      if (this.row-i>=0 && this.column-i >=0) {
        if (mainBoard[row-i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column-i]);
        } else if (mainBoard[row-i][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //up-right
    for (int i=1; i<8; i++) {
      if (this.row-i>=0 && this.column+i <=7) {
        if (mainBoard[row-i][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column+i]);
        } else if (mainBoard[row-i][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down-right
    for (int i=1; i<8; i++) {
      if (this.row+i<=7 && this.column+i <=7) {
        if (mainBoard[row+i][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column+i]);
        } else if (mainBoard[row+i][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down-left
    for (int i=1; i<8; i++) {
      if (this.row+i<=7 && this.column-i >=0) {
        if (mainBoard[row+i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column-i]);
        } else if (mainBoard[row+i][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    if (kingCalc==false) {
      for (int i=0; i<legalMoves.size(); i++) {
        legalMoves.get(i).setLegalMove(true);
      }
    }
  }
  
  public boolean isWhite(){
    return isWhite;
  }
}
public void boardSetup() {
  int type=-1;
  int y=150;
  int number=0;
  for (int i=0; i<8; i++){
    int x=150;
    for (int j=0; j<8; j++) {
      mainBoard[i][j]=new boardSpot(x,y,type);
      mainBoard[i][j].setBoardNumber(number);
      number++;
      x+=100;
      type*=-1;
    }
    type*=-1;
    y+=100;
  }
  //BLACK PIECES
  //PAWNS
  int x=150;
  for(int i=0; i<8; i++){
    y=250;
    blackPieces.add(new Pawn(x,y,1));
    x+=100;
  }
  //ROOKS
  blackPieces.add(new Rook(150,150,1,true));
  blackPieces.add(new Rook(850,150,1,false));
  //KNIGHTS
  blackPieces.add(new Knight(250,150,1));
  blackPieces.add(new Knight(750,150,1));
  //BISHOPS
  blackPieces.add(new Bishop(350,150,1,true));
  blackPieces.add(new Bishop(650,150,1,false));
  //KING AND QUEEN
  blackPieces.add(new Queen(450,150,1));
  blackPieces.add(new King(550,150,1));
  
  //WHITE PIECES
  //PAWNS
  x=150;
  for(int i=0; i<8; i++){
    y=750;
    whitePieces.add(new Pawn(x,y,-1));
    x+=100;
  }
  //ROOKS
  whitePieces.add(new Rook(150,850,-1,true));
  whitePieces.add(new Rook(850,850,-1,false));
  //KNIGHTS
  whitePieces.add(new Knight(250,850,-1));
  whitePieces.add(new Knight(750,850,-1));
  //BISHOPS
  whitePieces.add(new Bishop(350,850,-1,false));
  whitePieces.add(new Bishop(650,850,-1,true));
  //KING AND QUEEN
  whitePieces.add(new Queen(450,850,-1));
  whitePieces.add(new King(550,850,-1));
}
public class boardSpot
{
  float x;
  float y;
  int type;
  int fill;
  int column;
  int row;
  boolean legalMove;
  boolean shouldRemove;
  int currentPiece; //0=none,1=black,-1=white
  int boardNumber;
  public boardSpot(float x, float y, int type)
  {
    this.x=x;
    this.y=y;
    this.type=type;
    switch(type){
      case -1:
      fill=255;
      break;
      
      case 1:
      fill=0;
      break;
    }
    calculatePosition();
    legalMove=false;
    shouldRemove=false;
  }
  public void calculatePosition(){
    this.column=PApplet.parseInt((this.x-150)/100);
    this.row=PApplet.parseInt((this.y-150)/100);
  }
  public void display(){
    rectMode(CENTER);
    noStroke();
    if(legalMove==false){
      fill(fill);
    }
    else{
      fill(0,255,0);
    }
    square(x,y,100);
    if(mousePressed==true && pieceSelected==true && mouseButton==LEFT && dist(this.x,this.y,mouseX,mouseY)<49 && mouseDelay==false){
      selectedSpot=this;
      mouseDelay=true;
    }
    updatePiece();
  }
  public void updatePiece()
  {
    for(int i=0; i<whitePieces.size(); i++){
      if(whitePieces.get(i).getColumn()==column && whitePieces.get(i).getArrayRow()==row){
        currentPiece=-1;
        break;
      }
    }
    for(int i=0; i<blackPieces.size(); i++){
      if(blackPieces.get(i).getColumn()==column && blackPieces.get(i).getArrayRow()==row){
        currentPiece=1;
        break;
      }
    }
  }
  public int getBoardNumber(){return boardNumber;}
  public int getColumn(){return column;}
  public int getArrayRow(){return row;}
  public float getX(){return x;}
  public float getY(){return y;}
  public int getCurrentPiece(){return currentPiece;}
  public boolean shouldRemove(){return shouldRemove;}
  public void setShouldRemove(boolean newRemove){this.shouldRemove=newRemove;}
  public void setLegalMove(boolean isLegalMove){legalMove=isLegalMove;}
  public void setCurrentPiece(int currentPiece){this.currentPiece=currentPiece;}
  public void setBoardNumber(int number){this.boardNumber=number;}
}
public class Brain
{
  int type; //-1=white, 1=black
  ArrayList<Perceptron> perceptrons;
  float[] weights;
  ArrayList<Move> yourMoves;
  ArrayList<Move> enemyMoves;
  ArrayList<Move> yourPositions;
  ArrayList<Move> enemyPositions;
  int points;
  //create new brain with new weights
  public Brain(int type)
  {
    weights= new float[4];
    yourMoves= new ArrayList<Move>();
    enemyMoves= new ArrayList<Move>();
    yourPositions= new ArrayList<Move>();
    enemyPositions= new ArrayList<Move>();
    perceptrons= new ArrayList<Perceptron>();
    this.type=type;
    switch(type)
    {
      case 1:
      perceptrons.add(new Perceptron(4));
      break;
      case -1:
      perceptrons.add(new Perceptron(4));
      break;
      //0= x node, 1=y node
    }
    points=0;
  }
  //create brain with premade weights
  public Brain(int type, float[] weights)
  {
    this.weights= weights;
    yourMoves= new ArrayList<Move>();
    enemyMoves= new ArrayList<Move>();
    yourPositions= new ArrayList<Move>();
    enemyPositions= new ArrayList<Move>();
    perceptrons= new ArrayList<Perceptron>();
    perceptrons= new ArrayList<Perceptron>();
    this.type=type;
    perceptrons.add(new Perceptron(weights));
  }
  public void think()
  {
    calculateInputs(type);
    Move result = perceptrons.get(0).output(yourMoves, enemyMoves, yourPositions, enemyPositions);
    if (type==-1) {
      selectedSpot=result.getBoardSpot();
      //whitePieces.get(result.getPieceNumber()).setSelected(true);
      whitePieces.get(result.getPieceNumber()).addLegalMove(result.getBoardSpot());
      whitePieces.get(result.getPieceNumber()).move(true);
    } else {
      selectedSpot=result.getBoardSpot();
      //whitePieces.get(result.getPieceNumber()).setSelected(true);
      blackPieces.get(result.getPieceNumber()).addLegalMove(result.getBoardSpot());
      blackPieces.get(result.getPieceNumber()).move(true);
      selectedSpot=null;
    }
  }
  //calculate Inputs
  public void calculateInputs(int type) {
    yourMoves.clear();
    enemyMoves.clear();
    yourPositions.clear();
    enemyPositions.clear();
    calculateYourPositions(type);
    allPossibleMovesBlackBrain(type);
    allPossibleMovesWhiteBrain(type);
  }
  public void calculateYourPositions(int type) {
    if (type==-1) {
      for (int i=0; i<whitePieces.size(); i++) {
        yourPositions.add(new Move(mainBoard[whitePieces.get(i).getArrayRow()][whitePieces.get(i).getColumn()], whitePieces.get(i)));
      }
      for (int i=0; i<blackPieces.size(); i++) {
        enemyPositions.add(new Move(mainBoard[blackPieces.get(i).getArrayRow()][blackPieces.get(i).getColumn()], blackPieces.get(i)));
      }
    }
    if (type==1) {
      for (int i=0; i<whitePieces.size(); i++) {
        enemyPositions.add(new Move(mainBoard[whitePieces.get(i).getArrayRow()][whitePieces.get(i).getColumn()], whitePieces.get(i)));
      }
      for (int i=0; i<blackPieces.size(); i++) {
        yourPositions.add(new Move(mainBoard[blackPieces.get(i).getArrayRow()][blackPieces.get(i).getColumn()], blackPieces.get(i)));
      }
    }
  }
  public void allPossibleMovesBlackBrain(int type) {
    for (int i=0; i<blackPieces.size(); i++) {
      blackPieces.get(i).caculateMoves(false);
      blackPieces.get(i).blackMovesCheck();
      for (int j=0; j<blackPieces.get(i).getAllMoves().size(); j++) {
        if (blackPieces.get(i).getAllMoves().get(j)!=null) {
          if (type==-1) {
            enemyMoves.add(new Move(blackPieces.get(i).getAllMoves().get(j), blackPieces.get(i)));
          } else {
            yourMoves.add(new Move(blackPieces.get(i).getAllMoves().get(j), blackPieces.get(i)));
          }
        }
      }
      blackPieces.get(i).deselectPositions();
    }
  }
  public void allPossibleMovesWhiteBrain(int type) {
    for (int i=0; i<whitePieces.size(); i++) {
      whitePieces.get(i).caculateMoves(false);
      whitePieces.get(i).whiteMovesCheck();
      for (int j=0; j<whitePieces.get(i).getAllMoves().size(); j++) {
        if(whitePieces.get(i).getAllMoves().get(j)!=null){
        if (type==1) {
          enemyMoves.add(new Move(whitePieces.get(i).getAllMoves().get(j), whitePieces.get(i)));
        } else {
          yourMoves.add(new Move(whitePieces.get(i).getAllMoves().get(j), whitePieces.get(i)));
        }
      }}
      whitePieces.get(i).deselectPositions();
    }
  }
  public float[] getWeights(){
    return perceptrons.get(0).getWeights();
  }
  public int getPoints(){
    return points;
  }
  public void addPoints(int amount){
    points+=amount;
  }
}
public void drawCheck() {
  insuffienct();
  fiftyMoves();
  stalemate();
  repeat();
}
public void repeat(){
  if(whiteRepeat==3 || blackRepeat==3){
    tied=true;
    gameOver=true;
  }
}
public void stalemate() {
  if (whitePieces.size()==1 && whitePieces.get(0).name=="king") {
    if (whiteChecked==false && whitePieces.get(0).getAllMoves().size()==0) {
      tied=true;
      gameOver=true;
    }
  }
  if (blackPieces.size()==1 && blackPieces.get(0).name=="king") {
    if (blackChecked==false && blackPieces.get(0).getAllMoves().size()==0) {
      tied=true;
      gameOver=true;
    }
  }
}
public void fiftyMoves() {
  if (turnsSince>=50) {
    tied=true;
    gameOver=true;
  }
}
public void insuffienct() {
  //insufficient material draw
  if (blackPieces.size()==1 && whitePieces.size()==1 && blackPieces.get(0).name()=="king" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  //King and Knight vs King
  if (blackPieces.size()==1 && whitePieces.size()==2 && blackPieces.get(0).name()=="king" && whitePieces.get(1).name()=="knight" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  if (blackPieces.size()==1 && whitePieces.size()==2 && blackPieces.get(0).name()=="king" && whitePieces.get(0).name()=="knight" && whitePieces.get(1).name()=="king") {
    tied=true;
    gameOver=true;
  }
  if (blackPieces.size()==2 && whitePieces.size()==0 && blackPieces.get(0).name()=="king" && blackPieces.get(1).name()=="knight" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  if (blackPieces.size()==2 && whitePieces.size()==0 && blackPieces.get(1).name()=="king" && blackPieces.get(0).name()=="knight" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  //King and Boshop vs King
  if (blackPieces.size()==1 && whitePieces.size()==2 && blackPieces.get(0).name()=="king" && whitePieces.get(1).name()=="bishop" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  if (blackPieces.size()==1 && whitePieces.size()==2 && blackPieces.get(0).name()=="king" && whitePieces.get(0).name()=="bishop" && whitePieces.get(1).name()=="king") {
    tied=true;
    gameOver=true;
  }
  if (blackPieces.size()==2 && whitePieces.size()==0 && blackPieces.get(0).name()=="king" && blackPieces.get(1).name()=="bishop" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  if (blackPieces.size()==2 && whitePieces.size()==0 && blackPieces.get(1).name()=="king" && blackPieces.get(0).name()=="bishop" && whitePieces.get(0).name()=="king") {
    tied=true;
    gameOver=true;
  }
  //King and Bishop vs King and Bishop
  if (blackPieces.size()==2 && whitePieces.size()==2) {
    boolean correct=false;
    if (blackPieces.get(0).name()=="king" && blackPieces.get(1).name()=="bishop") {
      if (whitePieces.get(0).name()=="king" && whitePieces.get(1).name()=="bishop") {
        Bishop one= (Bishop)blackPieces.get(1);
        Bishop two= (Bishop)whitePieces.get(1);
        if (one.isWhite()==two.isWhite()) {
          correct=true;
        }
      }
      if (whitePieces.get(1).name()=="king" && whitePieces.get(0).name()=="bishop") {
        Bishop one= (Bishop)blackPieces.get(1);
        Bishop two= (Bishop)whitePieces.get(0);
        if (one.isWhite()==two.isWhite()) {
          correct=true;
        }
      }
    }
    if (blackPieces.get(1).name()=="king" && blackPieces.get(0).name()=="bishop") {
      if (whitePieces.get(0).name()=="king" && whitePieces.get(1).name()=="bishop") {
        Bishop one= (Bishop)blackPieces.get(0);
        Bishop two= (Bishop)whitePieces.get(1);
        if (one.isWhite()==two.isWhite()) {
          correct=true;
        }
      }
      if (whitePieces.get(1).name()=="king" && whitePieces.get(0).name()=="bishop") {
        Bishop one= (Bishop)blackPieces.get(0);
        Bishop two= (Bishop)whitePieces.get(0);
        if (one.isWhite()==two.isWhite()) {
          correct=true;
        }
      }
    }
    if (correct==true) {
      correct=false;
      tied=true;
      gameOver=true;
    }
  }
}
public class King extends Piece {
  ArrayList<boardSpot> removables;
  boardSpot oldSpot;
  public King(float x, float y, int type) {
    super(x, y, type, "king",100);
    removables=new ArrayList<boardSpot>();
    oldSpot=mainBoard[row][column];
  }
  @Override
    public void caculateMoves(boolean kingCalc) {
    //up-left
    for (int i=1; i<2; i++) {
      if (this.row-i>=0 && this.column-i >=0) {
        if (mainBoard[row-i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column-i]);
        } else if (mainBoard[row-i][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //up-right
    for (int i=1; i<2; i++) {
      if (this.row-i>=0 && this.column+i <=7) {
        if (mainBoard[row-i][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column+i]);
        } else if (mainBoard[row-i][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down-right
    for (int i=1; i<2; i++) {
      if (this.row+i<=7 && this.column+i <=7) {
        if (mainBoard[row+i][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column+i]);
        } else if (mainBoard[row+i][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down-left
    for (int i=1; i<2; i++) {
      if (this.row+i<=7 && this.column-i >=0) {
        if (mainBoard[row+i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column-i]);
        } else if (mainBoard[row+i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //up
    for (int i=1; i<2; i++) {
      if (this.row-i>=0) {
        if (mainBoard[row-i][column].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column]);
        } else if (mainBoard[row-i][column].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down
    for (int i=1; i<2; i++) {
      if (this.row+i<=7) {
        if (mainBoard[row+i][column].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column]);
        } else if (mainBoard[row+i][column].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //left
    for (int i=1; i<2; i++) {
      if (this.column-i>=0) {
        if (mainBoard[row][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row][column-i]);
        } else if (mainBoard[row][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //right
    for (int i=1; i<2; i++) {
      if (this.column+i<=7) {
        if (mainBoard[row][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row][column+i]);
        } else if (mainBoard[row][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    if (beenMoved==false && type==-1 && whiteChecked==false) {
      if (mainBoard[7][5].getCurrentPiece()==0 && mainBoard[7][6].getCurrentPiece()==0) {
        for (int i=0; i<whitePieces.size(); i++) {
          if (whitePieces.get(i).name()=="rook") {
            Rook selectedPiece=(Rook)whitePieces.get(i);
            if (whitePieces.get(i).hasMoved()==false && selectedPiece.isLeftPiece()==false) {
              legalMoves.add(mainBoard[7][6]);
            }
          }
        }
      }
      if (mainBoard[7][1].getCurrentPiece()==0 && mainBoard[7][2].getCurrentPiece()==0 && mainBoard[7][3].getCurrentPiece()==0) {
        for (int i=0; i<whitePieces.size(); i++) {
          if (whitePieces.get(i).name()=="rook") {
            Rook selectedPiece=(Rook)whitePieces.get(i);
            if (whitePieces.get(i).hasMoved()==false && selectedPiece.isLeftPiece()==true) {
              legalMoves.add(mainBoard[7][2]);
            }
          }
        }
      }
    }
    if (beenMoved==false && type==1) {
      if (mainBoard[0][5].getCurrentPiece()==0 && mainBoard[0][6].getCurrentPiece()==0) {
        for (int i=0; i<blackPieces.size(); i++) {
          if (blackPieces.get(i).name()=="rook") {
            Rook selectedPiece=(Rook)blackPieces.get(i);
            if (blackPieces.get(i).hasMoved()==false && selectedPiece.isLeftPiece()==false) {
              legalMoves.add(mainBoard[0][6]);
            }
          }
        }
      }
      if (mainBoard[0][1].getCurrentPiece()==0 && mainBoard[0][2].getCurrentPiece()==0 && mainBoard[0][3].getCurrentPiece()==0) {
        for (int i=0; i<blackPieces.size(); i++) {
          if (blackPieces.get(i).name()=="rook") {
            Rook selectedPiece=(Rook)blackPieces.get(i);
            if (blackPieces.get(i).hasMoved()==false && selectedPiece.isLeftPiece()==true) {
              legalMoves.add(mainBoard[0][2]);
            }
          }
        }
      }
    }
    mainBoard[row][column].setCurrentPiece(0);
    if (kingCalc==false) {
      if (type==-1) {
        allPossibleMovesBlack();
        for (int x=0; x<legalMoves.size(); x++) {
          for (int j=0; j<blackMoveList.size(); j++) {
            if (legalMoves.get(x).getArrayRow()==blackMoveList.get(j).getArrayRow() && legalMoves.get(x).getColumn()==blackMoveList.get(j).getColumn()) {
              legalMoves.get(x).setShouldRemove(true);
            }
          }
        }
        for (int i=0; i<legalMoves.size(); i++) {
          if (legalMoves.get(i).shouldRemove()==true) {
            legalMoves.set(i, null);
          }
        }
      } else {
        allPossibleMovesWhite();
        for (int i=0; i<this.legalMoves.size(); i++) {
          for (int j=0; j<whiteMoveList.size(); j++) {
            if (legalMoves.get(i).getArrayRow()==whiteMoveList.get(j).getArrayRow() && legalMoves.get(i).getColumn()==whiteMoveList.get(j).getColumn()) {
              legalMoves.get(i).setShouldRemove(true);
              break;
            }
          }
        }
        for (int i=0; i<legalMoves.size(); i++) {
          if (legalMoves.get(i).shouldRemove()==true) {
            legalMoves.set(i, null);
          }
        }
      }
    }
    mainBoard[row][column].setCurrentPiece(type);
    if (kingCalc==false) {
      for (int i=0; i<legalMoves.size(); i++) {
        if (legalMoves.get(i)!=null) {
          legalMoves.get(i).setLegalMove(true);
        }
      }
    }
  }
  public void setOldSpot(boardSpot newOld){
    this.oldSpot=newOld;
  }
  public boardSpot getOldSpot(){
    return oldSpot;
  }
}
public class Knight extends Piece{
  public Knight(float x, float y, int type){
    super(x,y,type,"knight",6);
  }
  @Override
  public void caculateMoves(boolean kingCalc){
    if(this.row>=2){
      if(this.column>=1){
        if(mainBoard[this.row-2][this.column-1].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row-2][this.column-1]);
        }
      }
      if(this.column<7){
        if(mainBoard[this.row-2][this.column+1].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row-2][this.column+1]);
        }
      }
    }
    if(this.row<=5){
      if(this.column>=1){
        if(mainBoard[this.row+2][this.column-1].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row+2][this.column-1]);
        }
      }
      if(this.column<7){
        if(mainBoard[this.row+2][this.column+1].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row+2][this.column+1]);
        }
      }
    }
    if(this.column>=2){
      if(this.row>=1){
        if(mainBoard[this.row-1][this.column-2].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row-1][this.column-2]);
        }
      }
      if(this.row<7){
        if(mainBoard[this.row+1][this.column-2].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row+1][this.column-2]);
        }
      }
    }
    if(this.column<=5){
      if(this.row>=1){
        if(mainBoard[this.row-1][this.column+2].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row-1][this.column+2]);
        }
      }
      if(this.row<7){
        if(mainBoard[this.row+1][this.column+2].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[this.row+1][this.column+2]);
        }
      }
    }
    if (kingCalc==false) {
      for (int i=0; i<legalMoves.size(); i++) {
        legalMoves.get(i).setLegalMove(true);
      }
    }
  }
}
public class Move{
  boardSpot movePosition;
  Piece pieceThatMoves;
  int pieceNumber;
  int spotNumber;
  public Move(boardSpot movePosition, Piece pieceThatMoves){
    this.movePosition=movePosition;
    this.pieceThatMoves=pieceThatMoves;
    this.spotNumber=movePosition.getBoardNumber();
    this.pieceNumber=pieceThatMoves.getPieceNumber();
  }
  public boardSpot getBoardSpot(){
    return movePosition;
  }
  public int getPieceNumber(){
    return pieceNumber;
  }
  public int getSpotNumber(){
    return spotNumber;
  }
}
public class Pawn extends Piece {
  int pawnToRemove;
  public Pawn(float x, float y, int type) {
    super(x, y, type, "pawn",1);
    pawnToRemove=-1;
  }
  public int removePawn(){
    return pawnToRemove;
  }
  public void resetRemover(){
    pawnToRemove=-1;
  }
  @Override
    public void caculateMoves(boolean kingCalc) {
    legalMoves.clear();
    if (beenMoved==false && kingCalc==false) {
      if (type==-1) {
        if (this.row>=2) {
          if (mainBoard[this.row-1][this.column].getCurrentPiece()==0) {
            legalMoves.add(mainBoard[this.row-1][this.column]);
            if (mainBoard[this.row-2][this.column].getCurrentPiece()==0) {
              legalMoves.add(mainBoard[this.row-2][this.column]);
            }
          }
        }
      } else {
        if (this.row<=5) {
          if (mainBoard[this.row+1][this.column].getCurrentPiece()==0) {
            legalMoves.add(mainBoard[this.row+1][this.column]);
            if (mainBoard[this.row+2][this.column].getCurrentPiece()==0) {
              legalMoves.add(mainBoard[this.row+2][this.column]);
            }
          }
        }
      }
    } else if (kingCalc==false) {
      if (type==-1) {
        if (this.row>=1) {
          if (mainBoard[this.row-1][this.column].getCurrentPiece()==0) {
            legalMoves.add(mainBoard[this.row-1][this.column]);
          }
        }
      } else {
        if (this.row<=6) {
          if (mainBoard[this.row+1][this.column].getCurrentPiece()==0) {
            legalMoves.add(mainBoard[this.row+1][this.column]);
          }
        }
      }
    }
    if (type==-1) {
      if (this.column>0 && this.row>0) {
        if (mainBoard[this.row-1][this.column-1].getCurrentPiece()==1) {
          legalMoves.add(mainBoard[this.row-1][this.column-1]);
        }
      }
      if (this.column<7 && this.row>0) {
        if (mainBoard[this.row-1][this.column+1].getCurrentPiece()==1) {
          legalMoves.add(mainBoard[this.row-1][this.column+1]);
        }
      }
    } else {
      if (this.column>0 && this.row<7) {
        if (mainBoard[this.row+1][this.column-1].getCurrentPiece()==-1) {
          legalMoves.add(mainBoard[this.row+1][this.column-1]);
        }
      }
      if (this.column<7 && this.row<7) {
        if (mainBoard[this.row+1][this.column+1].getCurrentPiece()==-1) {
          legalMoves.add(mainBoard[this.row+1][this.column+1]);
        }
      }
    }
    //EN PESSEANT MOVE
    if (kingCalc==false) {
      if (type==-1) {
        if (this.column>0 && this.row==3) {
          for (int i=0; i<blackPawns.size(); i++) {
            if (blackPawns.get(i).name()=="pawn") {
              if(blackPawns.get(i).getArrayRow()==3 && blackPawns.get(i).getColumn()==this.column-1){
                legalMoves.add(mainBoard[this.row-1][this.column-1]);
                for(int j=0; j<blackPieces.size();j++){
                  if(blackPieces.get(j)==blackPawns.get(i)){
                    pawnToRemove=j;
                  }
                }
              }
            }
          }
        }
        if (this.column<7 && this.row==3) {
          for (int i=0; i<blackPawns.size(); i++) {
            if (blackPawns.get(i).name()=="pawn") {
              if(blackPawns.get(i).getArrayRow()==3 && blackPawns.get(i).getColumn()==this.column+1){
                legalMoves.add(mainBoard[this.row-1][this.column+1]);
                for(int j=0; j<blackPieces.size();j++){
                  if(blackPieces.get(j)==blackPawns.get(i)){
                    pawnToRemove=j;
                  }
                }
              }
            }
          }
        }
      }
      if (type==1) {
        if (this.column>0 && this.row==4) {
          for (int i=0; i<whitePawns.size(); i++) {
            if (whitePawns.get(i).name()=="pawn") {
              if(whitePawns.get(i).getArrayRow()==4 && whitePawns.get(i).getColumn()==this.column-1){
                legalMoves.add(mainBoard[this.row+1][this.column-1]);
                for(int j=0; j<whitePieces.size();j++){
                  if(whitePieces.get(j)==whitePawns.get(i)){
                    pawnToRemove=j;
                  }
                }
              }
            }
          }
        }
        if (this.column<7 && this.row==4) {
          for (int i=0; i<whitePawns.size(); i++) {
            if (whitePawns.get(i).name()=="pawn") {
              if(whitePawns.get(i).getArrayRow()==4 && whitePawns.get(i).getColumn()==this.column+1){
                legalMoves.add(mainBoard[this.row+1][this.column+1]);
                for(int j=0; j<whitePieces.size();j++){
                  if(whitePieces.get(j)==whitePawns.get(i)){
                    pawnToRemove=j;
                  }
                }
              }
            }
          }
        }
      }
    }
    if (kingCalc==true) {
      if (type==-1) {
        if (this.column>0 && this.row>0) {
          if (mainBoard[this.row-1][this.column-1].getCurrentPiece()!=type) {
            legalMoves.add(mainBoard[this.row-1][this.column-1]);
          }
        }
        if (this.column<7 && this.row>0) {
          if (mainBoard[this.row-1][this.column+1].getCurrentPiece()!=type) {
            legalMoves.add(mainBoard[this.row-1][this.column+1]);
          }
        }
      } else {
        if (this.column>0 && this.row<7) {
          if (mainBoard[this.row+1][this.column-1].getCurrentPiece()!=type) {
            legalMoves.add(mainBoard[this.row+1][this.column-1]);
          }
        }
        if (this.column<7 && this.row<7) {
          if (mainBoard[this.row+1][this.column+1].getCurrentPiece()!=type) {
            legalMoves.add(mainBoard[this.row+1][this.column+1]);
          }
        }
      }
    }
    if (kingCalc==false) {
      for (int i=0; i<legalMoves.size(); i++) {
        legalMoves.get(i).setLegalMove(true);
      }
    }
  }
}
public void pawnPromotion(boolean whitePawn) {
  int x=350;
  if (whitePawn==true) {
    for (int i=0; i<whitePieceImages.length; i++) {
      stroke(0);
      strokeWeight(4);
      noFill();
      rect(x, 950, 100, 100);
      image(whitePieceImages[i], x, 950);
      if (mousePressed==true && mouseButton==LEFT && dist(mouseX, mouseY, x, 950)<50 && mouseDelay==false) {
        pawnChoice=i;
        mouseDelay=true;
      }
      x+=100;
    }
  } else {
    for (int i=0; i<blackPieceImages.length; i++) {
      stroke(0);
      strokeWeight(4);
      noFill();
      rect(x, 950, 100, 100);
      image(blackPieceImages[i], x, 950);
      if (mousePressed==true && mouseButton==LEFT && dist(mouseX, mouseY, x, 950)<50 && mouseDelay==false) {
        pawnChoice=i;
        mouseDelay=true;
      }
      x+=100;
    }
  }
}
public class Perceptron
{
  float[] weights; //used to calculate an output based on inputs
  float c= 0.01f; //learning constraint
  //first GEN, weights are random
  public Perceptron(int numWeights)
  {
    //set how many weights we will have and then when first made, creates a set of random weights
    weights= new float[numWeights];
    for(int i=0; i<numWeights; i++)
    {
      weights[i]= random(0,1);
    }
  }
  //all other gen, weights are not random
  public Perceptron(float[] weights)
  {
    this.weights= weights;
  }
  //takes in the input nodes, must have same amount of weights as inputs
  public Move output(ArrayList<Move> yourMoves,ArrayList<Move> enemyMoves,ArrayList<Move> yourPositions,ArrayList<Move> enemyPositions)
  {
    float sum=0;
    for(int i=0; i<yourMoves.size();i++)
    {
      sum+= yourMoves.get(i).getPieceNumber()*weights[0];
      sum+= yourMoves.get(i).getSpotNumber()*weights[0];
    }
    for(int i=0; i<enemyMoves.size();i++)
    {
      sum+= enemyMoves.get(i).getPieceNumber()*weights[1];
      sum+= enemyMoves.get(i).getSpotNumber()*weights[1];
    }
    for(int i=0; i<yourPositions.size();i++)
    {
      sum+= yourPositions.get(i).getPieceNumber()*weights[2];
      sum+= yourPositions.get(i).getSpotNumber()*weights[2];
    }
    for(int i=0; i<enemyPositions.size();i++)
    {
      sum+= enemyPositions.get(i).getPieceNumber()*weights[3];
      sum+= enemyPositions.get(i).getSpotNumber()*weights[3];
    }
    int maxSum=5000;
    return activate(sum,yourMoves, maxSum);
  }
  public Move activate(float sum,ArrayList<Move> yourMoves, int maxSum)
  {
    int selection= PApplet.parseInt((sum/maxSum)*yourMoves.size());
    //println(yourMoves.size());
    if(yourMoves.size()==0){
      
    }
    return yourMoves.get(selection);
  }
  
  public float[] getWeights()
  {
    return weights;
  }
}
public class Piece {
  int column;
  int row;
  float x;
  float y;
  int type;
  String name;
  PImage pieceImage;
  boolean selected;
  boolean beenMoved;
  ArrayList<boardSpot> legalMoves;
  boolean hasCalculated;
  int numMoves;
  int pieceNumber;
  int points;
  public Piece(float x, float y, int type, String name, int points) {
    this.x=x;
    this.y=y;
    this.type=type;
    this.name=name;
    setImage();
    selected=false;
    beenMoved=false;
    calculatePosition();
    legalMoves= new ArrayList<boardSpot>();
    hasCalculated=false;
    this.points=points;
  }
  public void display() {
    imageMode(CENTER);
    image(pieceImage, x, y);
    if (mousePressed==true && mouseButton==LEFT && dist(this.x, this.y, mouseX, mouseY)<48 && mouseDelay==false && turn==type && pieceSelected==false && pawnPromote==false && turnHasHappened==true) {
      //println(row+" "+column);
      selected=true;
      selectedPiece=this;
      pieceSelected=true;
      mouseDelay=true;
      turnHasHappened=false;
      legalMoves.clear();
    }
    if (selected==true && mousePressed==true && mouseButton==RIGHT) {
      unSelect();
    }
    if (selected==true) {
      move(false);
    }
  }
  public void unSelect() {
    selected=false;
    selectedPiece=this;
    pieceSelected=false;
    selectedPiece=null;
    mouseDelay=false;
    deselectPositions();
    hasCalculated=false;
    legalMoves.clear();
  }
  public void setImage() {
    if (type==-1) {
      pieceImage= loadImage("white_"+name+".png");
    } else if (type==1) {
      pieceImage= loadImage("black_"+name+".png");
    }
  }
  public void calculatePosition() {
    this.column=PApplet.parseInt((this.x-150)/100);
    this.row=PApplet.parseInt((this.y-150)/100);
  }
  public void deselectPositions() {
    for (int i=0; i<legalMoves.size(); i++) {
      if (legalMoves.get(i)!=null) {
        legalMoves.get(i).setLegalMove(false);
      }
    }
    legalMoves.clear();
  }
  public void setCurrentX(int newCurrentX) {
    this.column=newCurrentX;
  }
  public void setCurrentY(int newCurrentY) {
    this.row=newCurrentY;
  }
  public void move(boolean AI)
  {
    if (AI==false) {
      calculatePosition();
      if (hasCalculated==false) {
        caculateMoves(false);
        if (type==-1) {
          whiteMovesCheck();
        } else {
          blackMovesCheck();
        }
        hasCalculated=true;
      }
    }
    if (selectedSpot!=null) {
      for (int i=0; i<this.legalMoves.size() || AI==true; i++) {
        if (legalMoves.get(i)!=null || AI==true) {
          if (selectedSpot==legalMoves.get(i) || AI==true) {
            if (this.name=="king" && this.type==-1) {
              if (row==7 && column==4 &&selectedSpot.getArrayRow()==7 &&selectedSpot.getColumn()==6) {
                for (int j=0; j<whitePieces.size(); j++) {
                  if (whitePieces.get(j).name()=="rook") {
                    Rook selectedPiece=(Rook)whitePieces.get(j);
                    if (selectedPiece.isLeftPiece()==false) {
                      whitePieces.get(j).setX(mainBoard[7][5].getX());
                      whitePieces.get(j).setY(mainBoard[7][5].getY());
                    }
                  }
                }
              }
              if (row==7 && column==4 &&selectedSpot.getArrayRow()==7 &&selectedSpot.getColumn()==2) {
                for (int j=0; j<whitePieces.size(); j++) {
                  if (whitePieces.get(j).name()=="rook") {
                    Rook selectedPiece=(Rook)whitePieces.get(j);
                    if (selectedPiece.isLeftPiece()==true) {
                      whitePieces.get(j).setX(mainBoard[7][3].getX());
                      whitePieces.get(j).setY(mainBoard[7][3].getY());
                    }
                  }
                }
              }
            } else if (this.name=="king" && this.type==1) {
              if (row==0 && column==4 &&selectedSpot.getArrayRow()==0 &&selectedSpot.getColumn()==6) {
                for (int j=0; j<blackPieces.size(); j++) {
                  if (blackPieces.get(j).name()=="rook") {
                    Rook selectedPiece=(Rook)blackPieces.get(j);
                    if (selectedPiece.isLeftPiece()==false) {
                      blackPieces.get(j).setX(mainBoard[0][5].getX());
                      blackPieces.get(j).setY(mainBoard[0][5].getY());
                    }
                  }
                }
              }
              if (row==0 && column==4 &&selectedSpot.getArrayRow()==0 &&selectedSpot.getColumn()==2) {
                for (int j=0; j<blackPieces.size(); j++) {
                  if (blackPieces.get(j).name()=="rook") {
                    Rook selectedPiece=(Rook)blackPieces.get(j);
                    if (selectedPiece.isLeftPiece()==true) {
                      blackPieces.get(j).setX(mainBoard[0][3].getX());
                      blackPieces.get(j).setY(mainBoard[0][3].getY());
                    }
                  }
                }
              }
            }
            if (name=="king") {
              King newKing= (King)this;
              if (newKing.getOldSpot()==selectedSpot) {
                if (type==-1) {
                  whiteRepeat++;
                }
                if (type==1) {
                  blackRepeat++;
                }
              } else {
                if (type==-1) {
                  whiteRepeat=0;
                }
                if (type==1) {
                  blackRepeat=0;
                }
              }
              newKing.setOldSpot(selectedSpot);
            }
            mainBoard[row][column].setCurrentPiece(0);
            this.x=selectedSpot.getX();
            this.y=selectedSpot.getY();
            selectedSpot.setCurrentPiece(this.type);
            selected=false;
            selectedPiece=null;
            pieceSelected=false;
            selectedSpot=null;
            beenMoved=true;
            mouseDelay=false;
            hasCalculated=false;
            numMoves++;
            if(gameType!=2){
               turn*=-1;
               turnChange=true;
            }
            if (name=="pawn") {
              turnsSince=0;
            } else {
              turnsSince++;
            }
            blackPawns.clear();
            whitePawns.clear();
            calculatePosition();
            if (name=="pawn" && type==-1 && row==2) {
              Pawn jumper= (Pawn)this;
              if (jumper.removePawn()!=-1 && blackPieces.get(jumper.removePawn()).getColumn()==this.column) {
                mainBoard[blackPieces.get(jumper.removePawn()).getArrayRow()][blackPieces.get(jumper.removePawn()).getColumn()].setCurrentPiece(0);
                blackPieces.remove(jumper.removePawn());
                jumper.resetRemover();
              }
            }
            if (name=="pawn" && type==1 && row==5) {
              Pawn jumper= (Pawn)this;
              if (jumper.removePawn()!=-1 && whitePieces.get(jumper.removePawn()).getColumn()==this.column) {
                mainBoard[whitePieces.get(jumper.removePawn()).getArrayRow()][whitePieces.get(jumper.removePawn()).getColumn()].setCurrentPiece(0);
                whitePieces.remove(jumper.removePawn());
                jumper.resetRemover();
              }
            }
            if (name=="pawn" && type==1 && row==3 && numMoves==1) {
              blackPawns.add(this);
            }
            if (name=="pawn" && type==-1 && row==4 && numMoves==1) {
              whitePawns.add(this);
            }
            if (name=="pawn") {
              Pawn jumper=(Pawn)this;
              jumper.resetRemover();
            }
            deselectPositions();
            destoryPiece();
            if (AI==true) {
              AI=false;
              break;
            }
          }
        }
      }
    }
  }
  public void destoryPiece() {
    if (type==-1) {
      for (int i=0; i<blackPieces.size(); i++) {
        if (blackPieces.get(i).getArrayRow()==row && blackPieces.get(i).getColumn()==column) {
          if (blackPieces.get(i).name()=="king") {
            winningPlayer=-1;
            gameOver=true;
            gameOverFrame=frameCount;
          }
          if(gameType==2){
            whiteBrain.addPoints(blackPieces.get(i).getPoints());
          }
          blackPieces.remove(i);
          turnsSince=0;
        }
      }
    } else {
      for (int i=0; i<whitePieces.size(); i++) {
        if (whitePieces.get(i).getArrayRow()==this.row && whitePieces.get(i).getColumn()==this.column) {
          if (whitePieces.get(i).name()=="king") {
            winningPlayer=1;
            gameOver=true;
            gameOverFrame=frameCount;
          }
          if(gameType==2){
            blackBrain.addPoints(whitePieces.get(i).getPoints());
          }
          whitePieces.remove(i);
          turnsSince=0;
        }
      }
    }
  }
  public void addLegalMove(boardSpot newMove) {
    this.legalMoves.add(newMove);
  }
  public void setSelected(boolean selected) {
    this.selected=selected;
  }
  public void setPieceNumber(int number) {
    this.pieceNumber=number;
  }
  public int getPieceNumber() {
    return pieceNumber;
  }
  public void clearMoves() {
    legalMoves.clear();
  }
  public void setX(float newX) {
    this.x=newX;
  }
  public void setY(float newY) {
    this.y=newY;
  }
  public void caculateMoves(boolean kingCalc) {
  }
  public int getPoints(){
    return points;
  }
  public float getX() {
    return x;
  }
  public float getY() {
    return y;
  }
  public int getColumn() {
    return column;
  }
  public int getArrayRow() {
    return row;
  }
  public String name() {
    return name;
  }
  public ArrayList<boardSpot> getAllMoves() {
    return legalMoves;
  }
  public boolean hasMoved() {
    return beenMoved;
  }
  public int getNumMoves() {
    return numMoves;
  }
  public void whiteMovesCheck() {
    for (int i=0; i<legalMoves.size(); i++) {
      if (legalMoves.get(i)!=null) {
        Piece tempPiece=null;
        int oldRow=row;
        int oldColumn=column;
        mainBoard[row][column].setCurrentPiece(0);
        this.row=legalMoves.get(i).getArrayRow();
        this.column=legalMoves.get(i).getColumn();
        int oldType=mainBoard[row][column].getCurrentPiece();
        mainBoard[row][column].setCurrentPiece(type);
        if (oldType==1) {
          for (int j=0; j<blackPieces.size(); j++) {
            if (blackPieces.get(j).getArrayRow()==row && blackPieces.get(j).getColumn()==column) {
              tempPiece=blackPieces.get(j);
              blackPieces.remove(j);
            }
          }
        }
        whiteCheckedTest=false;
        checkWhiteInCheckTest();
        if (whiteCheckedTest==true) {
          mainBoard[row][column].setCurrentPiece(oldType);
          this.row=oldRow;
          this.column=oldColumn;
          mainBoard[row][column].setCurrentPiece(type);
          legalMoves.get(i).setLegalMove(false);
          legalMoves.set(i, null);
          whiteCheckedTest=false;
        } else {
          mainBoard[row][column].setCurrentPiece(oldType);
          this.row=oldRow;
          this.column=oldColumn;
          mainBoard[row][column].setCurrentPiece(type);
        }
        if (tempPiece!=null) {
          blackPieces.add(tempPiece);
        }
      }
    }
  }
  public void blackMovesCheck() {
    for (int i=0; i<legalMoves.size(); i++) {
      if (legalMoves.get(i)!=null) {
        Piece tempPiece=null;
        int oldRow=row;
        int oldColumn=column;
        mainBoard[row][column].setCurrentPiece(0);
        this.row=legalMoves.get(i).getArrayRow();
        this.column=legalMoves.get(i).getColumn();
        int oldType=mainBoard[row][column].getCurrentPiece();
        mainBoard[row][column].setCurrentPiece(type);
        if (oldType==-1) {
          for (int j=0; j<whitePieces.size(); j++) {
            if (whitePieces.get(j).getArrayRow()==row && whitePieces.get(j).getColumn()==column) {
              tempPiece=whitePieces.get(j);
              whitePieces.remove(j);
            }
          }
        }
        blackCheckedTest=false;
        checkBlackInCheckTest();
        if (blackCheckedTest==true) {
          mainBoard[row][column].setCurrentPiece(oldType);
          this.row=oldRow;
          this.column=oldColumn;
          mainBoard[row][column].setCurrentPiece(type);
          legalMoves.get(i).setLegalMove(false);
          legalMoves.set(i, null);
          blackCheckedTest=false;
        } else {
          mainBoard[row][column].setCurrentPiece(oldType);
          this.row=oldRow;
          this.column=oldColumn;
          mainBoard[row][column].setCurrentPiece(type);
        }
        if (tempPiece!=null) {
          whitePieces.add(tempPiece);
        }
      }
    }
  }
}
public class Queen extends Piece {
  public Queen(float x, float y, int type) {
    super(x, y, type, "queen",10);
  }
  @Override
    public void caculateMoves(boolean kingCalc) {
    //up-left
    for (int i=1; i<8; i++) {
      if (this.row-i>=0 && this.column-i >=0) {
        if (mainBoard[row-i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column-i]);
        } else if (mainBoard[row-i][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //up-right
    for (int i=1; i<8; i++) {
      if (this.row-i>=0 && this.column+i <=7) {
        if (mainBoard[row-i][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column+i]);
        } else if (mainBoard[row-i][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down-right
    for (int i=1; i<8; i++) {
      if (this.row+i<=7 && this.column+i <=7) {
        if (mainBoard[row+i][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column+i]);
        } else if (mainBoard[row+i][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down-left
    for (int i=1; i<8; i++) {
      if (this.row+i<=7 && this.column-i >=0) {
        if (mainBoard[row+i][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column-i]);
        } else if (mainBoard[row+i][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //up
    for (int i=1; i<8; i++) {
      if (this.row-i>=0) {
        if (mainBoard[row-i][column].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row-i][column]);
        } else if (mainBoard[row-i][column].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row-i][column]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //down
    for (int i=1; i<8; i++) {
      if (this.row+i<=7) {
        if (mainBoard[row+i][column].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row+i][column]);
        } else if (mainBoard[row+i][column].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row+i][column]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //left
    for (int i=1; i<8; i++) {
      if (this.column-i>=0) {
        if (mainBoard[row][column-i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row][column-i]);
        } else if (mainBoard[row][column-i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row][column-i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    //right
    for (int i=1; i<8; i++) {
      if (this.column+i<=7) {
        if (mainBoard[row][column+i].getCurrentPiece()==0) {
          legalMoves.add(mainBoard[row][column+i]);
        } else if (mainBoard[row][column+i].getCurrentPiece()!=type) {
          legalMoves.add(mainBoard[row][column+i]);
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    if (kingCalc==false) {
      /*int oldRow=row;
      int oldCol=column;
      for (int i=0; i<legalMoves.size(); i++) {
        if (legalMoves.get(i)!=null) {
          mainBoard[row][column].setCurrentPiece(0);
          int oldType=legalMoves.get(i).getCurrentPiece();
          this.row=legalMoves.get(i).getArrayRow();
          this.column=legalMoves.get(i).getColumn();
          float oldX=x;
          float oldY=y;
          this.x=legalMoves.get(i).getX();
          this.y=legalMoves.get(i).getY();
          legalMoves.get(i).setCurrentPiece(-1);
          if (type==-1) {
            whiteCheckedTest=false;
            checkWhiteInCheckTest();
            if (whiteCheckedTest==true && oldType==0) {
              legalMoves.get(i).setCurrentPiece(oldType);
              legalMoves.set(i, null);
            }
            if (legalMoves.get(i)!=null) {
              legalMoves.get(i).setCurrentPiece(oldType);
            }
            whiteCheckedTest=false;
          }
          this.row=oldRow;
          this.column=oldCol;
          this.x=oldX;
          this.y=oldY;
          mainBoard[row][column].setCurrentPiece(type);
          calculatePosition();
        }
      }*/
      for (int i=0; i<legalMoves.size(); i++) {
        if (legalMoves.get(i)!=null) {
          legalMoves.get(i).setLegalMove(true);
        }
      }
    }
  }
}
public class Rook extends Piece {
  boolean leftPiece;
  public Rook(float x, float y, int type, boolean leftPiece) {
    super(x, y, type, "rook",5);
    this.leftPiece=leftPiece;
  }
  @Override
  public void caculateMoves(boolean kingCalc){
    //up
    for(int i=1; i<8; i++){
      if(this.getArrayRow()-i>=0){
        if(mainBoard[getArrayRow()-i][getColumn()].getCurrentPiece()==0){
          legalMoves.add(mainBoard[getArrayRow()-i][getColumn()]);
        }
        else if(mainBoard[getArrayRow()-i][getColumn()].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[getArrayRow()-i][getColumn()]);
          break;
        }
        else{break;}
      }
      else{break;}
    }
    //down
    for(int i=1; i<8; i++){
      if(this.getArrayRow()+i<=7){
        if(mainBoard[getArrayRow()+i][getColumn()].getCurrentPiece()==0){
          legalMoves.add(mainBoard[getArrayRow()+i][getColumn()]);
        }
        else if(mainBoard[getArrayRow()+i][getColumn()].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[getArrayRow()+i][getColumn()]);
          break;
        }
        else{break;}
      }
      else{break;}
    }
    //left
    for(int i=1; i<8; i++){
      if(this.getColumn()-i>=0){
        if(mainBoard[getArrayRow()][getColumn()-i].getCurrentPiece()==0){
          legalMoves.add(mainBoard[getArrayRow()][getColumn()-i]);
        }
        else if(mainBoard[getArrayRow()][getColumn()-i].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[getArrayRow()][getColumn()-i]);
          break;
        }
        else{break;}
      }
      else{break;}
    }
    //right
    for(int i=1; i<8; i++){
      if(this.getColumn()+i<=7){
        if(mainBoard[getArrayRow()][getColumn()+i].getCurrentPiece()==0){
          legalMoves.add(mainBoard[getArrayRow()][getColumn()+i]);
        }
        else if(mainBoard[getArrayRow()][getColumn()+i].getCurrentPiece()!=type){
          legalMoves.add(mainBoard[getArrayRow()][getColumn()+i]);
          break;
        }
        else{break;}
      }
      else{break;}
    }
    if (kingCalc==false) {
      for (int i=0; i<legalMoves.size(); i++) {
        legalMoves.get(i).setLegalMove(true);
      }
    }
  }
  public boolean isLeftPiece(){return leftPiece;}
}
public void blackWin() {
  //calculate all moves in each piece
  boolean checkMate=true;
  ArrayList<boardSpot> movesToMake= new ArrayList<boardSpot>();
  for (int i=0; i<whitePieces.size(); i++) {
    whitePieces.get(i).caculateMoves(false);
    //remove moves using check code
    whitePieces.get(i).whiteMovesCheck();
    //add remaining moves to list
    movesToMake.addAll(whitePieces.get(i).getAllMoves());
    whitePieces.get(i).deselectPositions();
  }
  //if list is 0, checkmate
  for(int i=0; i<movesToMake.size();i++){
    if(movesToMake.get(i)!=null){
      checkMate=false;
      break;
    }
  }
  if (checkMate==true) {
    winningPlayer=1;
    blackBrain.addPoints(100);
    gameOver=true;
    gameOverFrame=frameCount;
  }
  movesToMake.clear();
}
public void whiteWin() {
  //calculate all moves in each piece
  boolean checkMate=true;
  ArrayList<boardSpot> movesToMake= new ArrayList<boardSpot>();
  for (int i=0; i<blackPieces.size(); i++) {
    blackPieces.get(i).caculateMoves(false);
    //remove moves using check code
    blackPieces.get(i).blackMovesCheck();
    //add remaining moves to list
    movesToMake.addAll(blackPieces.get(i).getAllMoves());
    blackPieces.get(i).deselectPositions();
  }
  //if list is 0, checkmate
  for(int i=0; i<movesToMake.size();i++){
    if(movesToMake.get(i)!=null){
      checkMate=false;
      break;
    }
  }
  if (checkMate==true) {
    winningPlayer=-1;
    whiteBrain.addPoints(100);
    gameOver=true;
    gameOverFrame=frameCount;
  }
  movesToMake.clear();
}
  public void settings() {  size(1000, 1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ChessNeuralNet" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
